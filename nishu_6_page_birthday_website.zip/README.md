# Nishu Birthday Website 🎀

A 6-page, mobile-friendly birthday website built with plain HTML, CSS and JavaScript.

## Files
- `index.html` — welcome page
- `wishes.html` — birthday wishes
- `shayari.html` — original Hindi shayari
- `fun.html` — interactive mystery cards
- `letter.html` — birthday note
- `surprise.html` — final interactive surprise
- `style.css`, `script.js` — shared design and interactions

## Before publishing
Open `letter.html` and change `Someone wishing you well` to your name if you want to sign the note. You can also edit any wording directly in the HTML files.

## Publish on GitHub Pages
1. Download and extract this ZIP.
2. Create a new GitHub repository.
3. Upload **all files** from the extracted folder into the repository root (not the ZIP itself).
4. Go to **Settings → Pages**.
5. Choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
6. After GitHub finishes publishing, open the Pages URL shown there.

No build step or external JavaScript libraries are required. Google Fonts are optional; the site has fallback fonts.
