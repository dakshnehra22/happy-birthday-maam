
const messages={
 luck:["A good surprise is on its way. Keep that smile ready! 🌈","Your lucky charm today: a little confidence and a lot of laughter. 🍀","The universe says: make a wish and enjoy your cake. 🎂"],
 power:["Turning ordinary moments into fun ones. ✨","Making people smile without even trying. 🌷","Being wonderfully, unapologetically yourself. 🦋"],
 mission:["Take one photo today that makes you genuinely happy. 📸","Eat a bite of cake and make a big birthday wish. 🍰","Do one thing today just because it makes you happy. 💗"]
};
function showRandom(id){const el=document.getElementById(id);const arr=messages[id]||[];el.textContent=arr[Math.floor(Math.random()*arr.length)];el.classList.add('show')}
function openSurprise(){document.getElementById('finalGift').classList.add('show');sendHearts()}
function sendHearts(){const chars=['💗','💖','✨','💕','🌸'];for(let i=0;i<22;i++){const e=document.createElement('span');e.className='heart';e.textContent=chars[Math.floor(Math.random()*chars.length)];e.style.left=Math.random()*100+'vw';e.style.fontSize=(14+Math.random()*18)+'px';e.style.setProperty('--drift',(Math.random()*140-70)+'px');e.style.animationDuration=(3+Math.random()*3)+'s';document.body.appendChild(e);setTimeout(()=>e.remove(),6500)}}
